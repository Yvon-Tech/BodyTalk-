/* ============================================================
   BodyTalk — app.js
   No accounts. No cookies. No localStorage/sessionStorage.
   Everything below lives only in JS variables in memory and
   disappears on reload or when a chat view is left.
   ============================================================ */

(() => {
  'use strict';

  /* ---------------- DATA ---------------- */

  const FAQ_DATA = [
    {
      q: "Mes règles ne sont pas régulières, c'est grave ?",
      a: "Pas forcément. Dans les 2 à 3 premières années après les premières règles, les cycles sont souvent irréguliers — c'est normal le temps que le corps se règle. Si tu n'as aucune règle depuis plus de 3 mois, si elles sont très douloureuses au point de t'empêcher de vivre normalement, ou si tu as un doute de grossesse, parle-en à un centre de santé."
    },
    {
      q: "Comment savoir si je suis enceinte ?",
      a: "Le signe le plus fiable est un retard de règles, associé parfois à des nausées, une fatigue inhabituelle ou une sensibilité des seins. Un test de grossesse (pharmacie ou centre de santé, environ 2 semaines après un rapport à risque) donne une réponse fiable. En cas de doute, un centre de santé peut faire un test gratuitement dans la plupart des pays d'Afrique de l'Ouest."
    },
    {
      q: "C'est quoi le consentement ?",
      a: "C'est un accord libre, clair et donné sans pression, à chaque étape. Le silence, la peur de décevoir, ou le fait d'avoir dit oui avant ne comptent pas comme un consentement automatique pour la suite. Tu as le droit de changer d'avis à tout moment, même en plein milieu. Personne n'a le droit de te forcer, te faire boire, te faire du chantage ou insister jusqu'à ce que tu cèdes."
    },
    {
      q: "Comment se protéger d'une IST ou du VIH ?",
      a: "Le préservatif (masculin ou féminin), utilisé correctement à chaque rapport, reste la meilleure protection accessible. Le dépistage régulier permet de savoir où on en est, souvent gratuitement dans les centres de santé ou associations locales. En cas d'exposition à risque au VIH, il existe un traitement d'urgence (PEP/TPE) efficace s'il est pris dans les 48 à 72h — plus tôt c'est mieux."
    },
    {
      q: "J'ai des pertes ou des démangeaisons, dois-je m'inquiéter ?",
      a: "Des pertes légères et sans odeur font partie du cycle normal. Mais des démangeaisons fortes, une odeur inhabituelle, une couleur inhabituelle ou des douleurs méritent une consultation — ce sont souvent des infections simples à traiter rapidement si elles sont prises tôt. Ce n'est jamais honteux d'en parler à un professionnel de santé."
    },
    {
      q: "On me pousse à me marier ou à avoir des relations sexuelles, que puis-je faire ?",
      a: "Le mariage précoce et les relations forcées restent malheureusement fréquents dans la région, mais ce n'est pas une fatalité et des lois existent pour te protéger dans la plupart des pays d'AO. Tu peux en parler à un adulte de confiance hors du foyer (enseignant·e, infirmier·ère, tante), ou appeler directement une ligne d'écoute — va voir l'onglet SOS pour le numéro de ton pays."
    },
    {
      q: "La pilule du lendemain, c'est quoi et où la trouver ?",
      a: "C'est une contraception d'urgence à prendre le plus tôt possible après un rapport non protégé (idéalement dans les 72h, elle reste utile jusqu'à 5 jours mais devient moins efficace). Elle est en vente en pharmacie dans la plupart des pays d'AO, parfois gratuite en centre de santé. Elle ne protège pas des IST — pense au dépistage en complément."
    },
    {
      q: "Puis-je consulter un centre de santé sans que mes parents le sachent ?",
      a: "Ça dépend des pays et des structures, mais de nombreux centres de santé et associations jeunesse proposent des consultations confidentielles pour les adolescent·es, en particulier pour la contraception et le dépistage. N'hésite pas à demander directement en arrivant si c'est confidentiel — c'est une question légitime."
    },
    {
      q: "J'ai été forcé·e ou touché·e sans mon accord, que faire ?",
      a: "Ce n'est jamais de ta faute. Si c'est arrivé récemment, essaie si possible de ne pas te laver avant un examen médical (ça peut aider à documenter les faits si tu veux porter plainte plus tard, mais ce choix t'appartient entièrement). Un centre de santé peut proposer un traitement d'urgence contre le VIH et les grossesses non désirées. Tu peux aussi appeler une ligne d'écoute — regarde l'onglet SOS pour le numéro de ton pays, ou parle à Big Sister si tu veux d'abord juste en parler."
    }
  ];

  // Verified = confirmed via recent public/official sources.
  // "à vérifier" = the format exists regionally but this specific
  // country's line wasn't individually confirmed — we say so rather
  // than invent a number.
  const COUNTRIES = [
    {
      id: "ci", name: "Côte d'Ivoire",
      lines: [
        { label: "Enfance en danger / écoute", number: "116", verified: true, note: "Allô Enfant en Détresse — gratuit, 24/7." },
        { label: "Police secours", number: "111", verified: true, note: "Aussi joignable au 170 selon la zone." }
      ]
    },
    {
      id: "sn", name: "Sénégal",
      lines: [
        { label: "Enfance en danger / écoute", number: "116", verified: true, note: "Ligne nationale de protection de l'enfance." },
        { label: "Police secours", number: "17", verified: false, note: "Numéro courant en Afrique francophone — confirme localement." }
      ]
    },
    {
      id: "bf", name: "Burkina Faso",
      lines: [
        { label: "Enfance en danger / écoute", number: "116", verified: true, note: "Allo 116, gratuit, ministère de la Femme et de la Famille." },
        { label: "Police secours", number: "17", verified: true, note: "Numéro vert de la Police Nationale." }
      ]
    },
    {
      id: "ml", name: "Mali",
      lines: [
        { label: "Enfance en danger / écoute", number: "116", verified: false, note: "Numéro harmonisé régional — à confirmer selon la couverture actuelle." },
        { label: "Police secours", number: "17", verified: false, note: "Numéro courant en Afrique francophone — confirme localement." }
      ]
    },
    {
      id: "bj", name: "Bénin",
      lines: [
        { label: "Enfance en danger / écoute", number: "116", verified: false, note: "Numéro harmonisé régional — à confirmer selon la couverture actuelle." },
        { label: "Police secours", number: "17", verified: false, note: "Numéro courant en Afrique francophone — confirme localement." }
      ]
    },
    {
      id: "tg", name: "Togo",
      lines: [
        { label: "Enfance en danger / écoute", number: "116", verified: false, note: "Numéro harmonisé régional — à confirmer selon la couverture actuelle." },
        { label: "Police secours", number: "17", verified: false, note: "Numéro courant en Afrique francophone — confirme localement." }
      ]
    },
    {
      id: "gn", name: "Guinée",
      lines: [
        { label: "Enfance en danger / écoute", number: "116", verified: false, note: "Numéro harmonisé régional — à confirmer selon la couverture actuelle." },
        { label: "Police secours", number: "17", verified: false, note: "Numéro courant en Afrique francophone — confirme localement." }
      ]
    },
    {
      id: "ne", name: "Niger",
      lines: [
        { label: "Enfance en danger / écoute", number: "116", verified: false, note: "Numéro harmonisé régional — à confirmer selon la couverture actuelle." },
        { label: "Police secours", number: "17", verified: false, note: "Numéro courant en Afrique francophone — confirme localement." }
      ]
    }
  ];

  const SAFE_PLACES_GENERIC = [
    { title: "Centre de santé communautaire le plus proche", desc: "Premier point d'entrée pour un test, une contraception d'urgence, ou des soins après une agression. Demande si la consultation peut rester confidentielle." },
    { title: "Antenne locale du ministère en charge de la protection de l'enfance / de la famille", desc: "Présente dans la plupart des chefs-lieux de région. Le 116 (ou le numéro de police de ton pays, onglet SOS) peut t'indiquer l'adresse exacte et à jour." },
    { title: "Association ou ONG jeunesse locale", desc: "De nombreuses associations locales (planning familial, protection de l'enfance) proposent écoute et orientation gratuites — un centre de santé ou la ligne d'écoute peut te donner le contact le plus proche et vérifié." },
    { title: "Un adulte de confiance hors du foyer", desc: "Enseignant·e, infirmier·ère scolaire, tante ou grand-mère : parfois le chemin le plus rapide vers un lieu sûr est une personne, pas une adresse." }
  ];

  const CHECKUP_QUESTIONS = [
    { id: "mood", q: "Comment tu te sens aujourd'hui ?", opts: ["Plutôt bien", "Ça va, mitigé", "Difficile", "Très difficile"] },
    { id: "sleep", q: "Et ton sommeil ces derniers jours ?", opts: ["Je dors bien", "Un peu perturbé", "Je dors mal", "Je ne dors presque plus"] },
    { id: "support", q: "As-tu quelqu'un à qui parler si besoin ?", opts: ["Oui, facilement", "Oui, mais difficile d'oser", "Pas vraiment", "Personne"] },
    { id: "pressure", q: "Est-ce qu'on te met une pression (famille, relation, école) que tu as du mal à porter ?", opts: ["Non, pas particulièrement", "Un peu", "Oui, beaucoup", "Je ne sais pas comment le dire"] },
    { id: "safety", q: "Est-ce que tu te sens en sécurité, physiquement, en ce moment ?", opts: ["Oui", "Plutôt oui", "Pas vraiment", "Non"] }
  ];

  /* ---------------- STATE (memory only) ---------------- */
  const state = {
    checkupAnswers: {},
    checkupStep: 0,
    askHistory: [],
    sisterHistory: []
  };

  /* ---------------- NAV ---------------- */
  const views = document.querySelectorAll('.view');
  const navBtns = document.querySelectorAll('.navbtn');

  function showView(id) {
    views.forEach(v => v.classList.toggle('active', v.id === id));
    navBtns.forEach(b => b.classList.toggle('active', b.dataset.view === id));
    // Privacy: chat history is only ever kept in memory for the
    // current visit to that specific view. Leaving Big Sister wipes it.
    if (id !== 'view-sister') {
      state.sisterHistory = [];
      const t = document.getElementById('sisterThread');
      if (t) t.innerHTML = '';
    }
    if (id !== 'view-ask') {
      state.askHistory = [];
      const t = document.getElementById('askThread');
      if (t) t.innerHTML = '';
    }
    window.scrollTo(0, 0);
  }

  navBtns.forEach(b => b.addEventListener('click', () => showView(b.dataset.view)));
  document.querySelectorAll('[data-goto]').forEach(b =>
    b.addEventListener('click', () => showView(b.dataset.goto))
  );

  /* ---------------- TEXT-ONLY MODE ---------------- */
  const textModeBtn = document.getElementById('textModeBtn');
  textModeBtn.addEventListener('click', () => {
    const on = document.body.classList.toggle('text-mode');
    textModeBtn.setAttribute('aria-pressed', String(on));
  });

  /* ---------------- DISGUISE / QUITTER VITE ---------------- */
  const disguise = document.getElementById('disguise');
  let escCount = 0, escTimer = null;

  function enterDisguise() {
    disguise.hidden = false;
    document.title = "Cahier d'exercices — Mathématiques";
  }
  function exitDisguise() {
    disguise.hidden = true;
    document.title = "Cahier d'exercices — Mathématiques"; // stays neutral even when back
  }

  document.getElementById('exitBtn').addEventListener('click', enterDisguise);
  document.querySelectorAll('[data-exit]').forEach(b => b.addEventListener('click', enterDisguise));
  disguise.addEventListener('click', () => { /* single click on the fake page does nothing — avoids accidental reveal */ });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      escCount++;
      clearTimeout(escTimer);
      escTimer = setTimeout(() => { escCount = 0; }, 600);
      if (escCount >= 2) {
        escCount = 0;
        disguise.hidden ? enterDisguise() : exitDisguise();
      }
    }
  });
  // Reclicking the (fake) tab title area returns to the app
  disguise.querySelector('.disguise-bar').addEventListener('dblclick', exitDisguise);

  /* ---------------- FAQ ---------------- */
  const faqList = document.getElementById('faqList');
  FAQ_DATA.forEach(item => {
    const details = document.createElement('details');
    details.className = 'faq-item';
    details.innerHTML = `
      <summary class="faq-q">${item.q}<span class="chevron" aria-hidden="true">+</span></summary>
      <div class="faq-a">${item.a}</div>
    `;
    faqList.appendChild(details);
  });

  /* ---------------- CHECK-UP ---------------- */
  const checkupBody = document.getElementById('checkupBody');

  function renderCheckup() {
    if (state.checkupStep >= CHECKUP_QUESTIONS.length) {
      renderCheckupResult();
      return;
    }
    const q = CHECKUP_QUESTIONS[state.checkupStep];
    checkupBody.innerHTML = `
      <div class="cu-question">
        <p>${q.q}</p>
        <div class="cu-options">
          ${q.opts.map((o, i) => `<button class="cu-opt" data-idx="${i}" aria-pressed="false" type="button">${o}</button>`).join('')}
        </div>
      </div>
    `;
    checkupBody.querySelectorAll('.cu-opt').forEach(btn => {
      btn.addEventListener('click', () => {
        state.checkupAnswers[q.id] = { text: btn.textContent, idx: Number(btn.dataset.idx) };
        state.checkupStep++;
        renderCheckup();
      });
    });
  }

  function renderCheckupResult() {
    const a = state.checkupAnswers;
    const unsafe = a.safety && a.safety.idx >= 2;
    const heavy = (a.mood && a.mood.idx >= 2) || (a.pressure && a.pressure.idx >= 2);

    let html = `<div class="cu-result ${unsafe ? 'cu-alert' : ''}">`;
    if (unsafe) {
      html += `<p><strong>Ce que tu as répondu sur ta sécurité compte.</strong> Tu n'as pas à gérer ça seul·e. Une ligne d'écoute gratuite peut t'aider à trouver une prochaine étape, même petite.</p>
        <button class="btn-primary" type="button" data-goto2="view-sos">Voir les numéros SOS</button>`;
    } else if (heavy) {
      html += `<p>Merci d'avoir pris ces 2 minutes pour toi. Ce que tu traverses semble lourd en ce moment — c'est réel, et ça vaut la peine d'en parler à quelqu'un, que ce soit Big Sister, un adulte de confiance, ou une ligne d'écoute.</p>
        <button class="btn-primary" type="button" data-goto2="view-sister">Parler à Big Sister</button>`;
    } else {
      html += `<p>Merci d'avoir fait ce point avec toi-même. Continue à checker régulièrement comment tu te sens — c'est déjà un bon réflexe.</p>`;
    }
    html += `</div>
      <button class="btn-ghost" style="margin-top:14px" type="button" id="cuRestart">Refaire le check-up</button>`;
    checkupBody.innerHTML = html;

    const goto2 = checkupBody.querySelector('[data-goto2]');
    if (goto2) goto2.addEventListener('click', () => showView(goto2.dataset.goto2));
    checkupBody.querySelector('#cuRestart').addEventListener('click', () => {
      state.checkupAnswers = {}; state.checkupStep = 0; renderCheckup();
    });
  }
  renderCheckup();

  /* ---------------- SOS ---------------- */
  const countrySelect = document.getElementById('countrySelect');
  const sosNumbers = document.getElementById('sosNumbers');
  COUNTRIES.forEach(c => {
    const o = document.createElement('option'); o.value = c.id; o.textContent = c.name;
    countrySelect.appendChild(o);
  });

  function renderSos(countryId) {
    const c = COUNTRIES.find(x => x.id === countryId) || COUNTRIES[0];
    sosNumbers.innerHTML = c.lines.map(l => `
      <div class="sos-card">
        <h3>${l.label} <span class="badge ${l.verified ? 'badge-ok' : 'badge-check'}">${l.verified ? 'vérifié' : 'à confirmer'}</span></h3>
        <div class="sos-number"><a href="tel:${l.number.replace(/\s/g,'')}">${l.number}</a></div>
        <p>${l.note}</p>
      </div>
    `).join('');
  }
  countrySelect.addEventListener('change', () => renderSos(countrySelect.value));
  renderSos(COUNTRIES[0].id);

  /* ---------------- SAFE PLACES ---------------- */
  const placesCountry = document.getElementById('placesCountry');
  const placesList = document.getElementById('placesList');
  COUNTRIES.forEach(c => {
    const o = document.createElement('option'); o.value = c.id; o.textContent = c.name;
    placesCountry.appendChild(o);
  });
  function renderPlaces(countryId) {
    const c = COUNTRIES.find(x => x.id === countryId) || COUNTRIES[0];
    const childline = c.lines[0];
    placesList.innerHTML = `
      <div class="place-card" style="border-color:var(--gold)">
        <h3>Étape 1 — appelle le ${childline.number}</h3>
        <p>${childline.note} C'est le moyen le plus fiable d'être orienté·e vers un lieu sûr, réellement disponible aujourd'hui près de chez toi.</p>
      </div>
    ` + SAFE_PLACES_GENERIC.map(p => `
      <div class="place-card">
        <h3>${p.title}</h3>
        <p>${p.desc}</p>
      </div>
    `).join('');
  }
  placesCountry.addEventListener('change', () => renderPlaces(placesCountry.value));
  renderPlaces(COUNTRIES[0].id);

  /* ---------------- CHAT (Ask Anonyme + Big Sister) ---------------- */
  const SOS_TRIGGER = /(me tuer|me suicider|en finir|plus envie de vivre|me faire du mal|viol|violée|violé\b|agress)/i;

  function addMsg(thread, role, text) {
    const div = document.createElement('div');
    div.className = 'msg ' + (role === 'user' ? 'msg-user' : 'msg-bot');
    div.textContent = text;
    thread.appendChild(div);
    thread.scrollTop = thread.scrollHeight;
    return div;
  }

  function addSosNudge(thread) {
    const div = document.createElement('div');
    div.className = 'msg msg-bot msg-sos';
    div.innerHTML = `Si c'est urgent, tu n'as pas à attendre une réponse ici. <button class="link-btn" data-goto="view-sos" style="color:#fff">Voir les numéros SOS de ton pays →</button>`;
    thread.appendChild(div);
    div.querySelector('[data-goto]').addEventListener('click', (e) => showView(e.target.dataset.goto));
    thread.scrollTop = thread.scrollHeight;
  }

  async function sendChat({ endpoint, thread, input, history, form }) {
    const text = input.value.trim();
    if (!text) return;
    addMsg(thread, 'user', text);
    if (SOS_TRIGGER.test(text)) addSosNudge(thread);
    history.push({ role: 'user', content: text });
    input.value = '';

    const loading = document.createElement('div');
    loading.className = 'msg-loading';
    loading.textContent = '… écrit une réponse';
    thread.appendChild(loading);
    thread.scrollTop = thread.scrollHeight;

    const btn = form.querySelector('button[type="submit"]');
    btn.disabled = true;

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ history: history.slice(-8) })
      });
      loading.remove();
      if (!res.ok) throw new Error('bad status');
      const data = await res.json();
      const reply = data.reply || "Désolé·e, je n'ai pas pu répondre là — réessaie dans un instant.";
      addMsg(thread, 'bot', reply);
      history.push({ role: 'assistant', content: reply });
    } catch (err) {
      loading.remove();
      addMsg(thread, 'bot', "La connexion a échoué. Réessaie dans un instant — et si c'est urgent, va directement voir l'onglet SOS.");
    } finally {
      btn.disabled = false;
      input.focus();
    }
  }

  const askForm = document.getElementById('askForm');
  const askInput = document.getElementById('askInput');
  const askThread = document.getElementById('askThread');
  askForm.addEventListener('submit', (e) => {
    e.preventDefault();
    sendChat({ endpoint: '/api/ask-anonyme', thread: askThread, input: askInput, history: state.askHistory, form: askForm });
  });

  const sisterForm = document.getElementById('sisterForm');
  const sisterInput = document.getElementById('sisterInput');
  const sisterThread = document.getElementById('sisterThread');
  sisterForm.addEventListener('submit', (e) => {
    e.preventDefault();
    sendChat({ endpoint: '/api/big-sister', thread: sisterThread, input: sisterInput, history: state.sisterHistory, form: sisterForm });
  });

  /* ---------------- QR CODE ---------------- */
  try {
    // eslint-disable-next-line no-undef
    new QRCode(document.getElementById('qrcode'), {
      text: window.location.href.split('#')[0],
      width: 120, height: 120,
      colorDark: '#171B36', colorLight: '#ffffff'
    });
  } catch (e) { /* QR lib failed to load (offline) — footer still works without it */ }

  document.getElementById('printQr').addEventListener('click', () => window.print());

})();
