# BodyTalk

Site statique + 2 fonctions serverless (Ask Anonyme, Big Sister Bot), pensé pour la confidentialité et la légèreté.

## Déploiement (Vercel)

**Option A — via l'interface (le plus simple)**

1. Mets ce dossier sur GitHub (repo public ou privé, peu importe).
2. Va sur [vercel.com](https://vercel.com) → **Add New → Project** → importe le repo.
3. Vercel détecte automatiquement qu'il n'y a pas de framework ("Other") : laisse **Build Command** et **Output Directory** vides, ne change rien — le site est statique à la racine et `/api` est reconnu automatiquement comme des fonctions serverless.
4. Avant de cliquer sur "Deploy", ouvre **Environment Variables** et ajoute :
   - `LLAMA_API_KEY` = ta clé récupérée sur https://llama.developer.meta.com (compte développeur Meta requis)
5. Clique sur **Deploy**. C'est tout — pas de base de données, pas d'étape de build.

**Option B — via la CLI**

```bash
npm i -g vercel
cd bodytalk
vercel                       # première fois : suit les questions (nouveau projet)
vercel env add LLAMA_API_KEY # colle ta clé quand demandé
vercel --prod                # déploiement en production
```

Les deux endpoints appelés par le front sont automatiquement disponibles en prod à :
`/api/ask-anonyme` et `/api/big-sister` (fichiers `api/ask-anonyme.js` et `api/big-sister.js`, logique partagée dans `lib/llama.js`).

**Domaine** : Vercel donne un sous-domaine `xxx.vercel.app` gratuit dès le déploiement ; tu peux brancher un nom de domaine personnalisé ensuite dans **Settings → Domains**.

**Tester en local** :
```bash
vercel dev
```
lance le site + les fonctions `/api` sur `http://localhost:3000`, clé API lue depuis un fichier `.env` local (voir `.env.example`, à ne jamais committer).

## Pourquoi la Llama API (et pas "Meta AI" directement)

Il n'existe pas d'API publique de l'app grand public "Meta AI". Ce qui existe côté développeurs, c'est la **Llama API** de Meta (`llama.developer.meta.com`), compatible avec le format OpenAI. C'est elle qui est utilisée ici (`lib/llama.js`). Tu peux changer de modèle en éditant `LLAMA_MODEL` dans ce fichier si tu veux un modèle plus ou moins puissant.

## Ce qui a été respecté du cahier des charges

- **Pas de compte, pas de cookie, pas de localStorage/sessionStorage** — tout l'état (check-up, historique de chat) vit uniquement dans des variables JS en mémoire, remis à zéro au rechargement ou en quittant une vue de chat.
- **Bouton "Quitter vite"** — fixe, visible sur toutes les pages, plus raccourci Échap ×2 (utile si les mains tremblent ou si on doit faire vite sans viser un bouton).
- **Bannière "Ici on garde rien"** — affichée en permanence sous l'en-tête.
- **Poids** — le dossier complet (HTML/CSS/JS) pèse environ 80 Ko, bien sous la barre des 500 Ko. La seule ressource externe est la petite librairie de QR code (~30 Ko, chargée depuis cdnjs, aucun cookie déposé).
- **Mode 100% texte** — bouton "Aa" en haut à droite, désactive fonds colorés, ombres et animations.
- **QR code imprimable** — généré côté client, bouton "Imprimer le QR code".
- **FAQ, Ask Anonyme, Check-up, SOS, Big Sister, Safe Places (liste statique)** — les 6 fonctionnalités du brief, la page "Astuces réseau" a bien été retirée et la carte interactive remplacée par une liste.

## À vérifier avant mise en ligne réelle

Ce sont des points où j'ai fait des choix par prudence plutôt que d'improviser une fausse certitude — à trancher avec toi :

1. **Numéros SOS** : j'ai vérifié via recherche que le **116** est confirmé pour la Côte d'Ivoire, le Burkina Faso et le Sénégal, et que la police secours est confirmée à 111 (Côte d'Ivoire) et 17 (Burkina Faso). Pour le Mali, le Bénin, le Togo, la Guinée et le Niger, je n'ai pas trouvé de confirmation officielle récente — ces lignes sont marquées "à confirmer" dans l'interface plutôt que présentées comme sûres. Idéalement, une personne sur place ou une ONG partenaire (Child Helpline International, UNICEF local) confirme ou corrige ces numéros avant le lancement.
2. **Safe Places** : plutôt que d'inventer des adresses précises que je ne peux pas vérifier (ce qui serait dangereux si elles étaient fausses), la page oriente vers des *types* de lieux et vers l'appel au 116 en premier réflexe pour obtenir une orientation à jour. Si tu as une liste d'adresses vérifiées par une ONG partenaire, on peut facilement l'intégrer à la place.
3. **Modération du chat** : les deux prompts système (`ask-anonyme.js`, `big-sister.js`) interdisent explicitement tout contenu romantique/sexuel, et forcent une redirection vers SOS dès qu'un message évoque violence, abus ou idées suicidaires — avec un filet de sécurité côté serveur (`_shared.js`) qui détecte ces mots-clés indépendamment du prompt. Ceci dit, aucun filtrage par mots-clés n'est parfait. Avant un vrai lancement, je recommande un test à blanc avec de vrais types de messages (y compris des tentatives de contournement) pour ajuster les prompts.
4. **Zéro historique = zéro supervision** : par design, rien n'est loggé côté serveur, ce qui protège la vie privée mais veut aussi dire qu'il n'y a aucun moyen de repérer après coup un·e utilisateur·rice en danger si iel quitte la conversation sans cliquer sur SOS. C'est un vrai compromis produit, pas un détail technique — à valider consciemment.
5. **Coût et abus** : il n'y a actuellement aucune limite de débit sur les deux fonctions serverless. Avant mise en ligne publique, ajoute un rate-limit (par IP, via un middleware Vercel Edge Config, ou un service tiers comme Upstash) pour éviter qu'un usage abusif ne fasse exploser la facture Llama API.
